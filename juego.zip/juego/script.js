let xp = 0;
let salud = 100;
let oro = 50;
let armaActual = 0;
let luchando;
let saludMonstruo;
let inventario = ["bastón"];

const boton1 = document.querySelector('#boton1');
const boton2 = document.querySelector("#boton2");
const boton3 = document.querySelector("#boton3");
const texto = document.querySelector("#texto");
const xpTexto = document.querySelector("#xpTexto");
const saludTexto = document.querySelector("#saludTexto");
const oroTexto = document.querySelector("#oroTexto");
const estadisticasMonstruo = document.querySelector("#estadisticasMonstruo");
const nombreMonstruo = document.querySelector("#nombreMonstruo");
const saludMonstruoTexto = document.querySelector("#saludMonstruo");
const armas = [
    { nombre: 'bastón', poder: 5 },
    { nombre: 'daga', poder: 30 },
    { nombre: 'martillo de garra', poder: 50 },
    { nombre: 'espada', poder: 100 },
    //nuevas armas
    { nombre: 'espada sagrada', poder: 150 }, 
    { nombre: 'espada matadragones', poder: 300 } 
];
const monstruos = [
    {
        nombre: "slime",
        nivel: 2,
        salud: 15
    },
    {
        nombre: "bestia dentada",
        nivel: 8,
        salud: 60
    },
    {
        nombre: "dragón",
        nivel: 20,
        salud: 300
    }
];
const ubicaciones = [
    {
        nombre: "plaza del pueblo",
        "texto del botón": ["Ir a la tienda", "Ir a la cueva", "Luchar contra el dragón"],
        "funciones del botón": [irATienda, irACueva, lucharContraDragon],
        texto: "Estás en la plaza del pueblo. Ves un cartel que dice \"Tienda\"."
    },
    {
        nombre: "tienda",
        "texto del botón": ["Comprar 10 salud (10 oro)", "Comprar arma (30 oro)", "Ir a la plaza del pueblo"],
        "funciones del botón": [comprarSalud, comprarArma, irAPueblo],
        texto: "Entras en la tienda."
    },
    {
        nombre: "cueva",
        "texto del botón": ["Luchar contra slime", "Luchar contra bestia dentada", "Ir a la plaza del pueblo"],
        "funciones del botón": [lucharContraSlime, lucharContraBestia, irAPueblo],
        texto: "Entras en la cueva. Ves algunos monstruos."
    },
    {
        nombre: "lucha",
        "texto del botón": ["Atacar", "Esquivar", "Correr"],
        "funciones del botón": [atacar, esquivar, irAPueblo],
        texto: "Estás luchando contra un monstruo."
    },
    {
        nombre: "matar monstruo",
        "texto del botón": ["Ir a la plaza del pueblo", "Ir a la plaza del pueblo", "Ir a la plaza del pueblo"],
        "funciones del botón": [irAPueblo, irAPueblo, huevoDePascua],
        texto: 'El monstruo grita "¡Arg!" mientras muere. Ganas puntos de experiencia y encuentras oro.'
    },
    {
        nombre: "perder",
        "texto del botón": ["¿JUGAR DE NUEVO?", "¿JUGAR DE NUEVO?", "¿JUGAR DE NUEVO?"],
        "funciones del botón": [reiniciar, reiniciar, reiniciar],
        texto: "Muertes. vuelve a jugar eres un guerrero;"
    },
    {
        nombre: "ganar",
        "texto del botón": ["¿JUGAR DE NUEVO?", "¿JUGAR DE NUEVO?", "¿JUGAR DE NUEVO?"],
        "funciones del botón": [reiniciar, reiniciar, reiniciar],
        texto: "¡Has derrotado al dragón! ¡GANASTE EL JUEGO! si se pudo;"
    },
    {
        nombre: "huevo de pascua",
        "texto del botón": ["2", "8", "¿Ir a la plaza del pueblo?"],
        "funciones del botón": [elegirDos, elegirOcho, irAPueblo],
        texto: "Encuentras un juego secreto. Elige un número arriba. Diez números serán elegidos aleatoriamente entre 0 y 10. ¡Si el número que elijas coincide con uno de los números aleatorios, ganas!"
    }
];

// inicializar botones
boton1.onclick = irATienda;
boton2.onclick = irACueva;
boton3.onclick = lucharContraDragon;


function actualizar(ubicacion) {
    // Eliminar todas las clases de fondo anteriores
    document.body.classList.remove('plaza', 'tienda', 'cueva', 'lucha', 'ganar');

    // Agregar la clase de fondo correspondiente
    if (ubicacion.nombre === "plaza del pueblo") {
        document.body.classList.add('plaza');
    } else if (ubicacion.nombre === "tienda") {
        document.body.classList.add('tienda');
    } else if (ubicacion.nombre === "cueva") {
        document.body.classList.add('cueva');
    } else if (ubicacion.nombre === "lucha") {
        document.body.classList.add('lucha');
    } else if (ubicacion.nombre === "ganar") {
        document.body.classList.add('ganar');
    }

    // Actualizar los textos y botones
    estadisticasMonstruo.style.display = "none";
    boton1.innerText = ubicacion["texto del botón"][0];
    boton2.innerText = ubicacion["texto del botón"][1];
    boton3.innerText = ubicacion["texto del botón"][2];
    boton1.onclick = ubicacion["funciones del botón"][0];
    boton2.onclick = ubicacion["funciones del botón"][1];
    boton3.onclick = ubicacion["funciones del botón"][2];
    texto.innerHTML = ubicacion.texto;
}



function irAPueblo() {
    actualizar(ubicaciones[0]);
}

function irATienda() {
    actualizar(ubicaciones[1]);
}

function irACueva() {
    actualizar(ubicaciones[2]);
}

function comprarSalud() {
    if (oro >= 10) {
        oro -= 10;
        salud += 10;
        oroTexto.innerText = oro;
        saludTexto.innerText = salud;
    } else {
        texto.innerText = "No tienes suficiente oro para comprar salud.";
    }
}

function comprarArma() {
    if (armaActual < armas.length - 1) {
        if (oro >= 30) {
            oro -= 30;
            armaActual++;
            oroTexto.innerText = oro;
            let nuevaArma = armas[armaActual].nombre;
            texto.innerText = "Ahora tienes un(a) " + nuevaArma + ".";
            inventario.push(nuevaArma);
            texto.innerText += " En tu inventario tienes: " + inventario;
        } else {
            texto.innerText = "No tienes suficiente oro para comprar un arma. vuelva pronto";
        }
    } else {
        texto.innerText = "¡Ya tienes la arma más poderosa!";
        boton2.innerText = "Vender arma por 15 oro";
        boton2.onclick = venderArma;
    }
}

function venderArma() {
    if (inventario.length > 1) {
        oro += 15;
        oroTexto.innerText = oro;
        let armaActual = inventario.shift();
        texto.innerText = "Vendiste un(a) " + armaActual + ".";
        texto.innerText += " En tu inventario tienes: " + inventario;
    } else {
        texto.innerText = "¡No vendas tu única arma!";
    }
}

function lucharContraSlime() {
    luchando = 0;
    irALucha();
}

function lucharContraBestia() {
    luchando = 1;
    irALucha();
}

function lucharContraDragon() {
    luchando = 2;
    irALucha();
}

function irALucha() {
    actualizar(ubicaciones[3]);
    saludMonstruo = monstruos[luchando].salud;
    estadisticasMonstruo.style.display = "block";
    nombreMonstruo.innerText = monstruos[luchando].nombre;
    saludMonstruoTexto.innerText = saludMonstruo;
}

function atacar() {
    texto.innerText = "El " + monstruos[luchando].nombre + " ataca.";
    texto.innerText += " Lo atacas con tu " + armas[armaActual].nombre + ".";
    salud -= obtenerValorDeAtaqueMonstruo(monstruos[luchando].nivel);
    if (esGolpeDeMonstruo()) {
        saludMonstruo -= armas[armaActual].poder + Math.floor(Math.random() * xp) + 1;
    } else {
        texto.innerText += " Fallas el ataque suerte para la proxima.";
    }
    saludTexto.innerText = salud;
    saludMonstruoTexto.innerText = saludMonstruo;
    if (salud <= 0) {
        perder();
    } else if (saludMonstruo <= 0) {
        if (luchando === 2) {
            ganarJuego();
        } else {
            derrotarMonstruo();
        }
    }
    if (Math.random() <= .1 && inventario.length !== 1) {
        texto.innerText += " Tu " + inventario.pop() + " se rompe. ya valio";
        armaActual--;
    }
}

function obtenerValorDeAtaqueMonstruo(nivel) {
    const golpe = (nivel * 5) - (Math.floor(Math.random() * xp));
    console.log(golpe);
    return golpe > 0 ? golpe : 0;
}

function esGolpeDeMonstruo() {
    return Math.random() > .2 || salud < 20;
}

function esquivar() {
    texto.innerText = "Esquivas el ataque del " + monstruos[luchando].nombre;
}

function derrotarMonstruo() {
    oro += Math.floor(monstruos[luchando].nivel * 6.7);
    xp += monstruos[luchando].nivel;
    oroTexto.innerText = oro;
    xpTexto.innerText = xp;
    actualizar(ubicaciones[4]);
}

function perder() {
    actualizar(ubicaciones[5]);
}

function ganarJuego() {
    actualizar(ubicaciones[6]);
}

function reiniciar() {
    xp = 0;
    salud = 100;
    oro = 50;
    armaActual = 0;
    inventario = ["bastón"];
    oroTexto.innerText = oro;
    saludTexto.innerText = salud;
    xpTexto.innerText = xp;
    irAPueblo();
}

function huevoDePascua() {
    actualizar(ubicaciones[7]);
}

function elegirDos() {
    elegir(2);
}

function elegirOcho() {
    elegir(8);
}

function elegir(escogido) {
    const numeros = [];
    while (numeros.length < 10) {
        numeros.push(Math.floor(Math.random() * 11));
    }
    texto.innerText = "Elegiste " + escogido + ". Aquí están los números aleatorios:\n";
    for (let i = 0; i < 10; i++) {
        texto.innerText += numeros[i] + "\n";
    }
    if (numeros.includes(escogido)) {
        texto.innerText += "¡Correcto! Ganas 20 oro!";
        oro += 20;
        oroTexto.innerText = oro;
    } else {
        texto.innerText += "¡Incorrecto! Pierdes 10 salud!";
        salud -= 10;
        saludTexto.innerText = salud;
        if (salud <= 0) {
            perder();
        }
    }
}

